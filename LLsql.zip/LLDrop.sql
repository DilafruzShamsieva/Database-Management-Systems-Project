USE LogicalLimitDB;

ALTER TABLE Subscription DROP FOREIGN KEY subscription_ibfk_1;
ALTER TABLE Parent DROP FOREIGN KEY parent_ibfk_1;
DROP TABLE Child;
DROP TABLE Subscription;
DROP TABLE Parent;
