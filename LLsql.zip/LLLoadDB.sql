USE LogicalLimitDB;

-- Insert into Parent table first
INSERT INTO Parent (fname, lname, DOB, phone, email, child, spouse, ssn, subscription)
VALUES
    ('Jimmy', 'John', '1980-05-10', '123-456-7890', 'john@fake.com', '98765432101', NULL, '12345678901', true),
    ('Jane', 'Lady', '1975-08-30', '987-654-3210', 'jane@fake.com', '98765432102', NULL, '23456789012', true),
    ('Michael', 'Jaxon', '1982-03-15', '555-555-5555', 'michael@fake.com', '98765432103', '98765432303', '34567890123', false);

-- Then insert into Child and Subscription tables
INSERT INTO Child (fname, lname, DOB, age, ssn, pssn)
VALUES
    ('Billy', 'John', '2005-01-15', 18, '12345678901', '98765432101'),
    ('Little', 'Lady', '2018-07-22', 5, '23456789012', '98765432102'),
    ('Maxon', 'Jaxon', '2013-03-10', 10, '34567890123', '98765432103');

INSERT INTO Subscription (Status, Type, Amount, Ssn, Active_Since, Inactive_Since)
VALUES
    (true, 'Basic', 19.99, '12345678901', '2023-01-01 12:00:00', NULL),
    (true, 'Premium', 39.99, '23456789012', '2023-02-15 14:30:00', NULL),
    (false, 'Pro', 59.99, '34567890123', '2023-03-20 10:15:00', '2023-05-05 16:45:00');