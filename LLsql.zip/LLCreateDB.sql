#CREATE DATABASE LogicalLimitDB;
USE LogicalLimitDB;

CREATE TABLE Device (
    Status BOOLEAN DEFAULT true,
    Type VARCHAR(50),
    OS VARCHAR(50),
    Device_id VARCHAR(11) PRIMARY KEY,
    child VARCHAR(50),
    FOREIGN KEY (child) REFERENCES Child(Pssn)
);

CREATE TABLE Task (
    Status BOOLEAN DEFAULT true,
	Description VARCHAR(50),
    Task_id VARCHAR(11) PRIMARY KEY,
    Points Varchar (20),
    child VARCHAR(50),
    FOREIGN KEY (child) REFERENCES Child(pssn)
);

CREATE TABLE EmergencySignal (
    Status BOOLEAN DEFAULT true,
    Signal_id VARCHAR(11) PRIMARY KEY,
    Signal_Type VARCHAR(50),
	Signal_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    child VARCHAR(50),
    FOREIGN KEY (child) REFERENCES Child(pssn)
);

CREATE TABLE Location (
    Status BOOLEAN DEFAULT true,
    Location_id VARCHAR(11) PRIMARY KEY,
    Signal_Type VARCHAR(50),
    Latitude DECIMAL (10, 8) NOT NULL,
    Longitude Decimal (11, 8) NOT NULL,
    child VARCHAR(50),
    FOREIGN KEY (child) REFERENCES Child(pssn)
);

CREATE TABLE Usage_Report (
    Report_ID VARCHAR(11) PRIMARY KEY,
	Usage_Details VARCHAR(255),
    Report_Time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    parent VARCHAR(11),
    FOREIGN KEY (parent) REFERENCES Parent(ssn)
);

CREATE TABLE Child (
    fname VARCHAR(50),
    lname VARCHAR(50),
    DOB DATE,
    age INT,
    ssn VARCHAR(11),
    pssn VARCHAR(11) PRIMARY KEY
);

 CREATE TABLE Parent (
    fname VARCHAR(50),
    lname VARCHAR(50),
    DOB DATE,
    phone VARCHAR(15),
    email VARCHAR(100),
    child VARCHAR(50),
    spouse VARCHAR(50),
    subscription BOOLEAN DEFAULT false,
    sign_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ssn VARCHAR(11) PRIMARY KEY,
    FOREIGN KEY (child) REFERENCES Child(Pssn)
);

CREATE TABLE Subscription (
    Status BOOLEAN DEFAULT true,
    Type VARCHAR(50),
    Amount DECIMAL(10, 2),
    Ssn VARCHAR(11) PRIMARY KEY,
    Active_Since TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Inactive_Since TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (Ssn) REFERENCES Parent(ssn)
);